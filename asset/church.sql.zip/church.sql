-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2020 at 05:32 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `church`
--

-- --------------------------------------------------------

--
-- Table structure for table `anak`
--

CREATE TABLE `anak` (
  `id` int(11) NOT NULL,
  `nia` varchar(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tanggal_lahir` varchar(30) NOT NULL,
  `anak_ke` varchar(20) NOT NULL,
  `pendidikan` varchar(200) NOT NULL,
  `nij_ayah` varchar(100) NOT NULL,
  `nij_ibu` varchar(100) NOT NULL,
  `bergabung` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `anak`
--

INSERT INTO `anak` (`id`, `nia`, `nama`, `jenis_kelamin`, `tanggal_lahir`, `anak_ke`, `pendidikan`, `nij_ayah`, `nij_ibu`, `bergabung`) VALUES
(36, 'DA-001', 'wiwin ade antony', 'Perempuan', '2019-07-28', '1', 'belum ada', 'D-002', 'D-003', 1581431752);

-- --------------------------------------------------------

--
-- Table structure for table `baptis`
--

CREATE TABLE `baptis` (
  `id` int(11) NOT NULL,
  `kode` varchar(11) NOT NULL,
  `nij` varchar(11) NOT NULL,
  `nama` varchar(200) NOT NULL,
  `lahir_di` varchar(100) NOT NULL,
  `tgl_lahir` varchar(30) NOT NULL,
  `tgl_baptis` varchar(30) NOT NULL,
  `ayah` varchar(200) NOT NULL,
  `ibu` varchar(200) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `jemaat` varchar(200) NOT NULL,
  `pembaptis` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `baptis`
--

INSERT INTO `baptis` (`id`, `kode`, `nij`, `nama`, `lahir_di`, `tgl_lahir`, `tgl_baptis`, `ayah`, `ibu`, `alamat`, `jemaat`, `pembaptis`, `status`, `date`) VALUES
(13, 'BS-001', 'D-002', 'Junian Alfredo Antony', 'Kupang', '1989-02-05', '2015-12-08', 'Yulen Rehardika Antony', 'Serliani Tresnawaty', 'Jl. Gunung Lumut No. 55A', 'gbi Destiny', 'pdt. Ongky Ola', 1, 1581425964);

-- --------------------------------------------------------

--
-- Table structure for table `jemaat`
--

CREATE TABLE `jemaat` (
  `id` int(11) NOT NULL,
  `nij` varchar(11) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `tanggal_lahir` varchar(30) NOT NULL,
  `alamat` varchar(250) NOT NULL,
  `status` varchar(20) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `bergabung` int(11) NOT NULL,
  `image` varchar(300) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(500) NOT NULL,
  `role_id` int(1) NOT NULL,
  `is_active` int(1) NOT NULL,
  `telepon` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jemaat`
--

INSERT INTO `jemaat` (`id`, `nij`, `nama`, `jenis_kelamin`, `tanggal_lahir`, `alamat`, `status`, `pekerjaan`, `bergabung`, `image`, `facebook`, `email`, `password`, `role_id`, `is_active`, `telepon`) VALUES
(1, 'D-001', 'Stefanus Ana Lalo', 'Laki-Laki', '1998-09-03', 'jl. gunung catur iv', 'Belum Menikah', 'karyawan', 1572112116, 'IMG_20180903_140620.jpg', 'stefano', 'steve@gmail.com', '$2y$10$YuI8pk/HUqBynlKgJoefoeG0PJiheu/zmPX8R9/VUvpi1kignPsh.', 1, 1, '082235743505'),
(2, 'D-002', 'Junian Alfredo Antony', 'Laki-Laki', '1989-02-05', 'Jl. Gunung Lumut No. 55A', 'Menikah', 'wiraswasta', 1581425367, 'default.jpg', 'Alfredo Antony', 'alfredo@gmail.com', '$2y$10$taY0DMDivePdWx2Wa9GCGeFQJZCCnIzUCF/miyDQWxzFI3fuYq.yq', 2, 1, '0811111111110'),
(15, 'D-003', 'Melita Ade Alfia', 'Perempuan', '1990-04-13', 'Jl. Gunung Lumut No. 55A', 'Menikah', 'wiraswasta', 1581426311, 'default.jpg', 'Ade Melita', 'alfia@gmail.com', '$2y$10$FgB7LgIKSAQCguyenTe0jefwcRIq9jV3gjzhuGt34SCENHcO9Lu4q', 2, 1, '0873300'),
(16, 'D-004', 'martenluter king', '', '', 'jl. bunga mawar', '', '', 1582281627, 'default.jpg', 'luter king', 'manrtenluter@gmail.com', '$2y$10$1rXkJ3gwMQg3m7uSUudsA.LvfDizSOf0v85n5nsgcjdGx9GLpvXye', 2, 0, '0889200'),
(17, 'D-005', 'pelipus', 'Laki-Laki', '2017-06-07', 'jl. guning fariam  1 no 5', 'Belum Menikah', 'swasta', 1582546119, 'default.jpg', 'pelipus', 'pelipus@gmail.com', '$2y$10$iBmNalFTXSzvWdffZfxuXuI8uL/mEMUfZDaagylUa4plZo57Up2HG', 2, 1, '09888');

-- --------------------------------------------------------

--
-- Table structure for table `jemaat_access_menu`
--

CREATE TABLE `jemaat_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jemaat_access_menu`
--

INSERT INTO `jemaat_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(6, 2, 2),
(8, 2, 6),
(22, 1, 5),
(23, 1, 3),
(24, 1, 6),
(25, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `jemaat_menu`
--

CREATE TABLE `jemaat_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jemaat_menu`
--

INSERT INTO `jemaat_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'Jemaat'),
(3, 'Menu'),
(5, 'Lister'),
(6, 'PnB');

-- --------------------------------------------------------

--
-- Table structure for table `jemaat_role`
--

CREATE TABLE `jemaat_role` (
  `id` int(11) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jemaat_role`
--

INSERT INTO `jemaat_role` (`id`, `role`) VALUES
(1, 'administrator'),
(2, 'jemaat');

-- --------------------------------------------------------

--
-- Table structure for table `jemaat_sub_menu`
--

CREATE TABLE `jemaat_sub_menu` (
  `1d` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `icon` varchar(200) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jemaat_sub_menu`
--

INSERT INTO `jemaat_sub_menu` (`1d`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 1, 'Dashboard', 'admin', 'fas fa-fw fa-tachometer-alt', 1),
(2, 2, 'My Profile', 'jemaat', 'fas fa-fw fa-user', 1),
(3, 2, 'Edit Profile', 'jemaat/edit', 'fas fa-fw fa-user-edit', 1),
(4, 3, 'Menu Manajemen', 'menu', 'fas fa-fw fa-folder', 1),
(5, 3, 'Submenu Manajemen', 'menu/submenu', 'fas fa-fw fa-folder-open', 1),
(6, 1, 'Role', 'admin/role', 'fas fa-fw fa-user-tie', 1),
(8, 5, 'Jemaat', 'lister', 'fas fa-fw fa-users', 1),
(9, 5, 'Anak Sekolah Minggu', 'lister/anak', 'fas fa-fw fa-child', 1),
(10, 2, 'Data Anak Anda', 'jemaat/anaksm', 'fas fa-fw fa-child	', 1),
(11, 6, 'Pernikahan', 'pnb', 'fas fa-fw fa-ring', 1),
(12, 6, 'Form Pendaftaran Nikah', 'pnb/daftarnikah', 'fas fa-fw fa-align-justify', 1),
(13, 6, 'Baptis', 'pnb/baptis', 'fas fa-fw fa-swimmer', 1),
(14, 6, 'Form Pendaftaran Baptis', 'pnb/daftarbaptis', 'fas fa-fw fa-resolving', 1),
(15, 5, 'Pernikahan', 'lister/nikah', 'fas fa-fw fa-ring	', 1),
(16, 5, 'Baptis', 'lister/baptis', 'fas fa-fw fa-swimmer', 1),
(17, 3, 'Buat Renungan', 'menu/buat_renungan', 'fas-fa-fw fa-plus-circle', 1);

-- --------------------------------------------------------

--
-- Table structure for table `nikah`
--

CREATE TABLE `nikah` (
  `id` int(11) NOT NULL,
  `kode` varchar(50) NOT NULL,
  `nij_laki` varchar(200) NOT NULL,
  `laki_lahir_di` varchar(150) NOT NULL,
  `tanggal_lahir_laki` varchar(30) NOT NULL,
  `ayah_laki` varchar(200) NOT NULL,
  `ibu_laki` varchar(200) NOT NULL,
  `nij_wanita` varchar(200) NOT NULL,
  `wanita_lahir_di` varchar(200) NOT NULL,
  `tanggal_lahir_wanita` varchar(30) NOT NULL,
  `ayah_wanita` varchar(200) NOT NULL,
  `ibu_wanita` varchar(200) NOT NULL,
  `dihadapan` varchar(200) NOT NULL,
  `dbkah` varchar(300) NOT NULL,
  `saksi1` varchar(200) NOT NULL,
  `saksi2` varchar(200) NOT NULL,
  `tanggal_nikah` varchar(30) NOT NULL,
  `yang_menyalin` varchar(200) NOT NULL,
  `status` int(1) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `nikah`
--

INSERT INTO `nikah` (`id`, `kode`, `nij_laki`, `laki_lahir_di`, `tanggal_lahir_laki`, `ayah_laki`, `ibu_laki`, `nij_wanita`, `wanita_lahir_di`, `tanggal_lahir_wanita`, `ayah_wanita`, `ibu_wanita`, `dihadapan`, `dbkah`, `saksi1`, `saksi2`, `tanggal_nikah`, `yang_menyalin`, `status`, `date`) VALUES
(25, 'DN-001', 'D-002', 'Kupang', '1990-04-13', 'Yulen Rehardika Antony', 'Serliani Tresnawaty', 'D-003', 'Ambon', '1990-04-13', 'Cristoper Colombus', 'Marry Anna', 'Pdt. Hermos Utta Baru', 'Perkawinan', 'roby andika', 'Brodeky leunt', '2018-08-08', 'Sefvy Lianty Umma', 1, 1581430276),
(26, 'DN-002', 'D-005', 'sumba', '2017-06-07', 'julen', 'marta', 'D-006', 'kupang', '2017-05-29', 'jonatan', 'marlina', '', '', 'hans', 'yunus', '', '', 0, 1582546296);

-- --------------------------------------------------------

--
-- Table structure for table `renungan`
--

CREATE TABLE `renungan` (
  `id` int(11) NOT NULL,
  `kode` varchar(11) NOT NULL,
  `title` varchar(350) NOT NULL,
  `poster` varchar(500) NOT NULL,
  `judul` varchar(500) NOT NULL,
  `kategori` varchar(50) NOT NULL,
  `time` int(11) NOT NULL,
  `content` text NOT NULL,
  `gambar` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `renungan`
--

INSERT INTO `renungan` (`id`, `kode`, `title`, `poster`, `judul`, `kategori`, `time`, `content`, `gambar`) VALUES
(1, 'BR-001', 'Berterimakasih Kepada Mereka Yang Mulaikai Anda', 'Berterimakasih Kepada Mereka Yang Mulaikai Anda', 'Berterimakasih Kepada Mereka Yang Mulaikai Anda', 'renungan', 1584799204, '<p>Sebuah tulisan dari AWANAMA berbunyi;<br>\r\nPerkataan sembrono dapat mencetuskan perselisihan<br>\r\nPerkataan kasar dapat merusak sebuah kehidupan\r\nPerkataan pahit dapat menyemaikan kebencian\r\nPerkataan brutal dapat menghantam dan membunuh\r\nPerkataan ramah dapat memperlancar jalan\r\nPerkataan menggembirakan dapat menyinari hari\r\nPerkataan yang tepat waktunya dapat mengurangi stress\r\nPerkataan penuh cinta dapat menyembuhkan dan memberi rahmat.</p>\r\n\r\n<p>Nabi Solaiman pernah berkata bahwa, hidup dan mati dikuasai oleh lidah. Lidah mempunyai kuasa untuk menyelamatkan kehidupan atau bahkan merusaknya; orang harus menanggung akibat ucapannya.  Banyak kali kita tidak menyadari dengan apa yang kita ucapkan sehingga kita dengan begitu sembrononya mengucapkan perkataan-perkataan negatif baik kepada diri kita, kepada pasangan kita, kepada anak-anak kita dan kepada sahabat dan teman-teman kita. \r\nBukankah kita sering melarang anak-anak kita untuk berhati-hati dan jangan bermain dengan api sebab nanti mereka bisa terbakar, dan seharusnya kita juga mengajar mereka untuk berhati-hati dengan perkataan mereka karena perkataan mereka dapat menentukan masa depan mereka.</p>\r\n\r\n<p>Kita semua harus ingat bahwa apa yang kita ucapkan, setiap perkataan yang keluar dari mulut kita memiliki kuasa entah itu menyembuhkan atau melukai, membangun atau menghancurkan, menghidupkan atau mematikan, memberi semangat atau melecehkan, menentukan masa depan atau sebaliknya menghancurkna masa depan anda. Jadi berhati-hatilah dengan apa yang anda ucapkan. Jika anda ingin menikmati hidup dan melihat hari-hari anda penuh dengan kebahagiaan maka anda harus belajar menjaga setiap perkataan yang keluar dari mulut anda. </p>', 'thanks.jpg'),
(2, 'BR-002', 'Bijaksanalah Dengan Perkataan Anda', 'Bijaksanalah Dengan Perkataan Anda', 'Bijaksanalah Dengan Perkataan Anda', 'renungan', 1584799774, 'Sebuah tulisan dari AWANAMA berbunyi;<br>\r\nPerkataan sembrono dapat mencetuskan perselisihan&lt;<br>\r\nPerkataan kasar dapat merusak sebuah kehidupan&lt;<br>\r\nPerkataan pahit dapat menyemaikan kebencian&lt;<br>\r\nPerkataan brutal dapat menghantam dan membunuh&lt;<br>\r\nPerkataan ramah dapat memperlancar jalan&lt;<br>\r\nPerkataan menggembirakan dapat menyinari hari<br>\r\nPerkataan yang tepat waktunya dapat mengurangi stress<br>\r\nPerkataan penuh cinta dapat menyembuhkan dan memberi rahmat.<br>\r\n\r\n<p>Nabi Solaiman pernah berkata bahwa, hidup dan mati dikuasai oleh lidah. Lidah mempunyai kuasa untuk menyelamatkan kehidupan atau bahkan merusaknya; orang harus menanggung akibat ucapannya.  Banyak kali kita tidak menyadari dengan apa yang kita ucapkan sehingga kita dengan begitu sembrononya mengucapkan perkataan-perkataan negatif baik kepada diri kita, kepada pasangan kita, kepada anak-anak kita dan kepada sahabat dan teman-teman kita. \r\nBukankah kita sering melarang anak-anak kita untuk berhati-hati dan jangan bermain dengan api sebab nanti mereka bisa terbakar, dan seharusnya kita juga mengajar mereka untuk berhati-hati dengan perkataan mereka karena perkataan mereka dapat menentukan masa depan mereka.&lt;</p>\r\n<p>Kita semua harus ingat bahwa apa yang kita ucapkan, setiap perkataan yang keluar dari mulut kita memiliki kuasa entah itu menyembuhkan atau melukai, membangun atau menghancurkan, menghidupkan atau mematikan, memberi semangat atau melecehkan, menentukan masa depan atau sebaliknya menghancurkna masa depan anda. Jadi berhati-hatilah dengan apa yang anda ucapkan. Jika anda ingin menikmati hidup dan melihat hari-hari anda penuh dengan kebahagiaan maka anda harus belajar menjaga setiap perkataan yang keluar dari mulut anda.</p>', 'vision.jpg'),
(3, 'BR-003', 'CARA PANDANG YANG BENAR', 'CARA PANDANG YANG BENAR', 'CARA PANDANG YANG BENAR', 'renungan', 1584801282, '<p>Seorang anak selalu diintimidasi oleh temannya yang badannya sedikit lebih besar daripadanya. Setiap hari ia selalu takut jika berhadapan dengan temannya itu. Suatu hari ayahnya bertanya kepadanya; Nak, kenapa kamu takut dgn teman mu itu? Karena badannya lebih besar dari saya, jawab sang anak. Sang ayah kemudian mengambil sebuah teropong dan memberikannya kepada anaknya. Sekarang coba lihat temanmu menggunakan teropong ini, apa yg kamu lihat. Wah ayah, badannya besar sekali, jawab sang anak. Itulah yang menyebabkan saya takut terhadapnya. Sekarang coba kamu balik teropongnya, bagian kaca yang besar ada di matamu. Ah, ayah ternyata dia kelihatan kecil sekali, jawab sang anak? </p>\r\n\r\n<p>Sahabat, cara kita memandang persoalan dalam kehidupan akan sangat menentukan apakah kita dapat memenangkannya atau malah dikalahkan olehnya. Apakah kita dapat mengatasinya atau malah diperburuk olehnya? Apakah kita dapat ditumbuhkan olehnya atau ditarik kebawah olehnya? Apakah kita akan menjadi lebih baik atau malah menjadi lebih buruk. So, lihatlah persoalan dari kaca mata yang positif. Dan ubahlah cara anda memandangnya.</p>\r\n\r\n\r\n<p>Terkadang dibutuhkan kegelapan untuk melihat bintang-bintang. Kegelapan adalah masalah-masalah Anda yang tampak sangat berat dan membuat Anda hampir jatuh menyerah. Kilau bintang adalah cahaya impian masa depan Anda yang bersinar di dalam hati Anda. Namun pertanyaannya adalah &quot;Apakah kita mau berjuang menembus kegelapan itu dengan semangat pemberani dan mental pemenang untuk mendapatkan kilau bintang kita?&quot;\r\nPlease, don’t run from the sufferings but embrace it.</p>', 'pandangan.png'),
(4, 'BR-004', 'CHANGE YOUR WORDS, CHANGE YOUR WORLD', 'CHANGE YOUR WORDS, CHANGE YOUR WORLD', 'CHANGE YOUR WORDS, CHANGE YOUR WORLD', 'renungan', 1585029249, '<p>Lidah, meskipun merupakan bagian dari anggota tubuh yang kecil, tetapi dapat menyebabkan hal-hal besar terjadi dalam kehidupan anda. \r\nRiset menemukan bahwa rata-rata orang berpikir dalam sehari adalah 50.000 pikiran. Sedihnya adalah sebagian besar pikiran tersebut negative. Saya bodoh, saya tidak mungkin bisa berhasil, saya tidak akan lulus, …tidak peduli sekuat apa saya telah mencoba dan berusaha, semuanya akan sia-sia saja. Inilah yang disebut dalam psikologi sebagai bahasa korban. Bahasa korban selalu membuat anda akan terus menjadi kroban dalam pikiran anda.</p>\r\n\r\n<p>Supaya anda bisa mendapatkan apa  yang anda inginkan dalam kehidupan maka anda harus berhenti menggunakan bahasa korban ini dan mulailah berbicara kepada diri anda seperti seorang pemenang – saya pasti bisa.. saya tahu pasti ada solusi…saya cukup pintar dan cukup kuat untuk menyelesaikan masalah ini.\r\nInilah saatnya menggunakan perkataan anda untuk mengucapkan dan mendeklarasikan hal-hal yang positif. Perkatakanlah berkat atas hidup anda dan keluarga anda. Saat pagi hari sebelum anda memulai semua aktifitas anda katakanlah bahwa “hari ini akan menjadi hari yang luar biasa”, saya kuat dan mampu melalukan apa yang perlu saya lakukan, saya akan menyelesaikan hal-hal luar biasa hari ini. Saya akan bertemu dengan orang-orang yang luar biasa hari ini. </p>\r\n\r\n<p>Tahukah anda bahwa apa yang anda ucapkan tentang diri anda memiliki dampak yang besar atas hidup anda daripada apa yang orang lain ucapkan tentang anda? \r\nPada waktu seseorang mengucapkan perkataan-perkataan negative atas hidup mereka, mereka tidak menyadari bahwa sesungguhnya mereka sedang mengucapkan kutuk atas hidup mereka dan masa depan mereka. </p>\r\n\r\n<p>Salah satu cara terbaik untuk bisa memiliki masa depan yang lebih baik dan menkmati hari-hari anda adalah dengan mulai mengucapkan perkataan-perkataan kemenangan. Setiap hari, lihatlah diri anda di depan cermin dan ucapkanlah, “saya sangat bergairah dengan masa depan saya”, “hari ini pasti aka lebih baik dari hari kemarin”, “saya dapat melakukan dan mencapai hal-hal luar biasa hari ini.”</p>', 'cange.jpg'),
(14, 'BR-014', 'DAMPAK DARI PERKATAAN', 'DAMPAK DARI PERKATAAN', 'DAMPAK DARI PERKATAAN', 'renungan', 1585030588, '<p>Pada tahun 1923 di Jerman Barat dirayakan misa pertama pada saat menjelang Natal, malam itu seorang anak dengan gemetar karena ini adalah saat pertama kalinya ia berdiri disebuah altar gereja membawa sebuah nampan yang berisikan secawan anggur dan beberapa roti ragi. Tiba-tiba tanpa disengaja sang anak tersandung sembulan karpet yang tidak rata di pijakan kakinya yang menyebabkan seluruh isi nampan yang dibawanya jatuh berantakan!!. </p>\r\n\r\n<p>Sang Pastor yang pada saat itu melihat kejadian tersebut sangatlah marah dan menampar si anak sambil berkata, \"Pergi!!! dan jangan kembali lagi!!! Kamu memang anak Bodoh!!!.\" </p>\r\n\r\n<p>20 tahun kemudian si anak menjadi seorang Tito, sebutan untuk seorang pemimpin komunis yang sangat bengis di Jerman Timur. </p>\r\n\r\n<p>Pada tahun 1931 di daerah Berlin Utara, dari pintu altar berjalan seorang anak yang baru pertama kali membawakan sebuah lilin dan secawan anggur pada nampannya, dengan gemetar ia melaju perlahan namun tiba-tiba tangannya menjadi begitu licin karena keringat, tiba-tiba saja nampan itu jatuh dan seluruh isinya berhamburan. \r\nSang pastor yang memimpin misa itu menghampiri sang anak dan berkata, \"Aku mengerti ini adalah saat pertama bagimu untuk membawakan perjamuan misa seperti ini, aku percaya satu saat nanti kau akan menjadi seorang Pemimpin pastor.\" \r\n20 tahun kemudian sang anak menjadi seorang pemimpin pastoral yang amat dihormati di Vatican.</p> \r\n\r\n<p>Perkataan yang anda ucapkan kepada seseorang sangat menentukan sikap atau tindakan seseorang di hari esok, entah itu pasanganmu, anakmu, saudaramu, keluargamu atau karyawanmu. Biasakanlah untuk memberikan kata-kata pujian, dorongan, kata-kata yang membangun, kata-kata yang penuh cinta kepada anak-anak anda. Ingat hal ini tidak memerlukan biaya yang mahal, anda tinggal membiasakan diri untuk mengtakannya setiap hari kepada orang-orang yang anda cintai. Sehingga mereka bertumbuh dengan rasa cinta dan kasih sayang dan pada gilirannya mereka akan melakukan hal yang sama dengan anak-anak mereka nantinya. Akhirnya kita sedang menghasilkan generasi-generasi yang luar biasa hidupnya dimasa depan.</p>', 'perkataan.png'),
(15, 'BR-015', 'DESERVE', 'DESERVE', 'DESERVE', 'renungan', 1585031119, '<p><i>We make a living by what we get. We make a life by what we give. Winston Churchill</i></p>\r\n\r\n<p>Kata Deserve yang artinya layak/Pantas, berasal dari bahasa latin yaitu “de” yang berarti dari. Dan kata “:service” yang artinya melayani. Secara harafiah kata deserve berarti “dari melayani”.</p>\r\n\r\n<p>Dengan demkian dapat disimpulkan bahwa semakin baik kita dalam melayani orang lain maka semakin banyak pula hal-hal baik dan luar biasa yang layak kita dapatkan dan menjadi milik kita.</p>\r\n \r\n<p>Seperti yang di katakan oleh Zig Ziglar, “You can have everything in life you want if you will just help enough other people get what they want.” (Anda bisa memiliki apa pun dalam hidup ini sepanjang Anda juga mau berusaha untuk membantu orang lain mendapatkan apa yang mereka inginkan).</p>\r\n\r\n<p>Seorang pemimpin besar pernah berkata; setiap orang yang mau menjadi besar di antara kalian, harus bersedia melayani (Yesus).</p>\r\n\r\n<p>Mari buang segala ego kita dan berlomba-lombalah untuk melayani orang lain dengan menolong mereka mencapai potensi maksimal mereka dan menjadi yang terbaik. Jika itu yang anda lakukan maka anda LAYAK mendapat yang terbaik bagi diri anda. Karena saat anda membuat dampak yang positif dalam kehidupan seseorang, maka anda juga sedang membuat dampak yang positif bagi diri anda sendiri. Sekalipun mungkin yang anda lakukan hanyalah hal yang kecil namun terkadang hal-hal kecil itu dapat berarti banyak bagi kehidupan seseorang.</p>\r\n\r\n<p><b>The things that you do for yourself, die with you.....the things that you do for others , mark your place in the world. Anonim</b></p>', 'deserve.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anak`
--
ALTER TABLE `anak`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `baptis`
--
ALTER TABLE `baptis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jemaat`
--
ALTER TABLE `jemaat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jemaat_access_menu`
--
ALTER TABLE `jemaat_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jemaat_menu`
--
ALTER TABLE `jemaat_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jemaat_role`
--
ALTER TABLE `jemaat_role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jemaat_sub_menu`
--
ALTER TABLE `jemaat_sub_menu`
  ADD PRIMARY KEY (`1d`);

--
-- Indexes for table `nikah`
--
ALTER TABLE `nikah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `renungan`
--
ALTER TABLE `renungan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anak`
--
ALTER TABLE `anak`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `baptis`
--
ALTER TABLE `baptis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `jemaat`
--
ALTER TABLE `jemaat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `jemaat_access_menu`
--
ALTER TABLE `jemaat_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `jemaat_menu`
--
ALTER TABLE `jemaat_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jemaat_role`
--
ALTER TABLE `jemaat_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jemaat_sub_menu`
--
ALTER TABLE `jemaat_sub_menu`
  MODIFY `1d` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `nikah`
--
ALTER TABLE `nikah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `renungan`
--
ALTER TABLE `renungan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
